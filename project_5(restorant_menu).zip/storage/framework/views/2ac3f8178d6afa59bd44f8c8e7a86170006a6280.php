

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.add_food_ingredient'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.block-header.min', ['data' => ['sub' => trans('main.add_food_ingredient'), 'title' => $food->name]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="nk-block-head">
        <div class="nk-block-between-md g-4">
            <div class="nk-block-head-content"></div>
            <div class="nk-block-head-content">
                <ul class="nk-block-tools gx-3">
                    <li>
                        <span class=" clone_ingredient btn btn-white btn-dim btn-outline-primary">
                            <em class="icon ni ni-plus-c"></em><span class="d-none d-sm-inline-block"><?php echo app('translator')->get('main.add'); ?></span>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <form action="<?php echo e(route('foods.ingredients.store', $food->id)); ?>" class="form-contact needs-validation" method="POST" novalidate>
            <?php echo csrf_field(); ?>
            <div>
                <div class="card card-bordered mb-2 copy_ingredient mt-4">
                    <div class="card-inner position-relative">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="area"><?php echo app('translator')->get('main.ingredient'); ?> </label>
                                    <div class="form-control-wrap">
                                        <select class="form-control <?php $__errorArgs = ['ingredient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="ingredient" name="ingredient_id[]" data-search="on" >
                                            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($ingredient->id); ?>"><?php echo e($ingredient->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('ingredient_id')): ?>
                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('ingredient_id')); ?></strong></span>
                                        <?php else: ?>
                                            <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="value" class="form-label"><?php echo app('translator')->get('main.value'); ?></label>
                                    <div class="form-control-wrap">
                                        <input type="number" id="value" name="value[]" class="form-control form-control-lg <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo app('translator')->get('main.value'); ?>"
                                               value="<?php echo e(old('value')); ?>" min="1" step="0.01">
                                        <?php if($errors->has('value')): ?>
                                          <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('value')); ?></strong></span>
                                        <?php else: ?>
                                          <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <span class="btn text-danger btn-sm edit-delete position-absolute remove_ingredient" style="top: -15px; right: -35px; font-size:30px " title="Remove"><em class="icon ni ni-cross-circle-fill"></em></span>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <button class="btn btn-primary"><?php echo app('translator')->get('main.submit'); ?></button>
            </div>
        </form>
        <?php if(count($food_ingredients)): ?>
            <div id="ingredients_wrapper" class="card card-bordered card-preview mt-4">
                <div class="card card-bordered card-preview">
                    <table class="table table-ulogs">
                        <thead class="thead-light">
                            <tr>
                                <th class="tb-col-os"><span class="overline-title"><?php echo app('translator')->get('main.name'); ?></span></th>
                                <th class="tb-col-time"><span class="overline-title"><?php echo app('translator')->get('main.value'); ?></span></th>
                                <th class="tb-col-action"><span class="overline-title">&nbsp;</span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $food_ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="tb-col-os" ><?php echo e($food_ing->ingredient->name); ?></td>
                                    <td class="tb-col-time"><?php echo e($food_ing->value); ?> <?php echo e($food_ing->ingredient->unit); ?></td>
                                    <td class="tb-col-action">
                                        <a href="#" class="link-cross mr-sm-n1"
                                            onclick="if (confirm('<?php echo e(trans("main.want_to_remove")); ?>')) { document.getElementById('destroy-<?php echo e($food_ing->id); ?>').submit(); }">
                                            <em class="icon ni ni-cross"></em>
                                        </a>
                                        <form action="<?php echo e(route('foods.ingredients.destroy', $food_ing->id)); ?>" method="post" id="destroy-<?php echo e($food_ing->id); ?>">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(function() {
      const remove = $(".remove_ingredient");
      const onremove = $(".onclick_remove_ingredient");
      $('b[role="presentation"]').hide();
      remove.click(function() {
        $(this).parents('.copy_ingredient').remove();
      });
      onremove.click(function() {
        $(this).parents('.on_copy_ingredient').remove();
      });
      let cloneDiv = $('.copy_ingredient').clone(true);
      $('.clone_ingredient').click(function() {
        cloneDiv.children()[0].value = '';
        $('.copy_ingredient').parent().append(cloneDiv.clone(true));
      });
      remove.remove();
    });

  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/MADO/resources/views/foods/ingredient/create.blade.php ENDPATH**/ ?>