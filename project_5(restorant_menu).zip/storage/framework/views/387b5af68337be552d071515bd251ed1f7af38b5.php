

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.create_new_food'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.block-header.min', ['data' => ['sub' => trans('main.create_new'), 'title' => trans('main.food')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('foods.store')); ?>" class="form-contact needs-validation" method="POST"
        enctype="multipart/form-data" novalidate>
        <?php echo csrf_field(); ?>
        <div class="card card-bordered mb-2">
            <div class="card-inner">
                <h5 class="float-title"><?php echo app('translator')->get('main.name'); ?></h5>
                <div class="row g-4">
                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="name-<?php echo e($localeCode); ?>"
                                    class="form-label"><?php echo e($properties['native']); ?></label>
                                <div class="form-control-wrap">
                                    <input type="text" id="name-<?php echo e($localeCode); ?>" name="name[<?php echo e($localeCode); ?>]"
                                        value="<?php echo e(old('name.' . $localeCode)); ?>"
                                        class="form-control form-control-lg <?php $__errorArgs = ['name.' . $localeCode];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="<?php echo e($properties['native']); ?>" required>
                                    <?php if($errors->has('name.' . $localeCode)): ?>
                                        <span class="invalid-feedback"
                                            role="alert"><strong><?php echo e($errors->first('name.' . $localeCode)); ?></strong></span>
                                    <?php else: ?>
                                        <span class="invalid-feedback"
                                            role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-12">
                <label for="file" class="form-label"><?php echo app('translator')->get('main.image'); ?></label>
                <div class="form-control-wrap">
                    <input type="file" id="file" name="file"
                        class="form-control form-control-lg <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="<?php echo app('translator')->get('main.choose_image'); ?>" required>
                    <?php if($errors->has('file')): ?>
                        <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('file')); ?></strong></span>
                    <?php else: ?>
                        <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label" for="category"><span><?php echo app('translator')->get('main.category'); ?></span></label>
                    <div class="form-control-wrap">
                        <select class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category"
                            name="category_id" data-search="on" data-ui="lg" required>
                            <option disabled hidden selected></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('category_id')): ?>
                            <span class="invalid-feedback"
                                role="alert"><strong><?php echo e($errors->first('category_id')); ?></strong></span>
                        <?php else: ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="discount" class="form-label"><?php echo app('translator')->get('main.discount'); ?></label>
                    <div class="input-group form-control-wrap">
                        <input class="form-control form-control-lg" type="number" name="discount" id="discount"
                            value="<?php echo e(old('discount')); ?>" min="1" step="0.01">
                        <div class="input-group-append input-card-type">
                            <select name="discount_unit" class="input-group-text form-select" aria-label="discount"
                                data-search="off" data-ui="lg">
                                <option value="manat" <?php if(old('discount_unit') == 'manat'): ?> selected <?php endif; ?>><?php echo app('translator')->get('main.manat'); ?></option>
                                <option value="percent" <?php if(old('discount_unit') == 'percent'): ?> selected <?php endif; ?>><?php echo app('translator')->get('main.percent'); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="sp-plan-opt">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="active" id="active" checked>
                        <label class="custom-control-label text-soft" for="active"><?php echo app('translator')->get('main.is_active'); ?></label>
                        <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                
                
                <div class="tab-content mb-36" id="priceTabContent">
                    <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade <?php echo e($key == 'single' ? 'show active' : ''); ?>" id="<?php echo e($key); ?>"
                            role="tabpanel" aria-labelledby="<?php echo e($key); ?>-tab">
                            
                                <div class="card card-bordered mb-2">
                                    <div class="card-inner">
                                        
                                        <h5 class="float-title"><?php echo app('translator')->get('main.price'); ?></h5>
                                        <?php if($tab['loop_count'] != 1): ?>
                                            <div class="form-group">
                                                <label for="size" class="d-block"><?php echo app('translator')->get('main.named_for_food_size'); ?></label>
                                                <div class="input-group">
                                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <input
                                                            class="form-control <?php echo e($errors->has('size.*.' . $localeCode) ? 'is-valid' : ''); ?>"
                                                            type="text" name="size[][<?php echo e($localeCode); ?>]"
                                                            aria-label="size-<?php echo e($localeCode); ?>"
                                                            placeholder="<?php echo e($properties['native']); ?>"
                                                            <?php echo e($key == 'single' ? 'required' : 'disabled'); ?>>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($errors->has('type.*.' . $localeCode)): ?>
                                                        <span class="invalid-feedback"
                                                            role="alert"><strong><?php echo e($errors->first('size.*.' . $localeCode)); ?></strong></span>
                                                    <?php else: ?>
                                                        <span class="invalid-feedback"
                                                            role="alert"><strong><?php echo app('translator')->get('main.must_write_size_name'); ?></strong></span>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <label for="price-<?php echo e($key); ?>"><?php echo app('translator')->get('main.price'); ?></label>
                                            <input type="number" id="price-<?php echo e($key); ?>" name="price[]" step="0.01"
                                                class="form-control no-arrow <?php echo e($errors->has('price.*') ? 'is-valid' : ''); ?>"
                                                <?php echo e($key == 'single' ? 'required' : 'disabled'); ?>>
                                            <?php if($errors->has('price.*')): ?>
                                                <span class="invalid-feedback"
                                                    role="alert"><strong><?php echo e($errors->first('price')); ?></strong></span>
                                            <?php else: ?>
                                                <span class="invalid-feedback"
                                                    role="alert"><strong><?php echo app('translator')->get('main.must_show_price'); ?></strong></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-12">
                <button class="btn btn-primary"><?php echo app('translator')->get('main.submit'); ?></button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('b[role="presentation"]').hide();

            $('#priceTab .nav-link').click(function() {
                let tab_input = $('.tab-pane input');
                let this_input = $('#' + $(this).attr('aria-controls') + ' input');

                tab_input.prop('disabled', true);
                tab_input.removeAttr('required');

                this_input.prop('disabled', false);
                this_input.prop('required', true);
            });

            let form_select = $(".form-select");
            let select = $(".form-select select");
            let has_category = $("#has_category");

            toggleForm(has_category);

            has_category.change(function() {
                toggleForm($(this));
            })
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pikir\gurnamalylar\soltan-loft\resources\views/foods/create.blade.php ENDPATH**/ ?>