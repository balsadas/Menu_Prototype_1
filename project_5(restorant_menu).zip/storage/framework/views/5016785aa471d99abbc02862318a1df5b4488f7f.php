<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.create_new_tablet_password'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.block-header.min', ['data' => ['sub' => trans('main.create_new'), 'title' => trans('main.tablet_password')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <form action="<?php echo e(route('passwords.store')); ?>" class="form-contact needs-validation" method="POST" novalidate>
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="password" class="form-label"><?php echo app('translator')->get('main.password'); ?></label>
      <div class="form-control-wrap">
        <input type="number" id="password" name="code" value="<?php echo e(old('code')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               placeholder="<?php echo app('translator')->get('main.password_placeholder'); ?>" min="10000" max="99999" required>
        <?php if($errors->has('code')): ?>
          <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('code')); ?></strong></span>
        <?php else: ?>
          <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.invalid_input'); ?></strong></span>
        <?php endif; ?>
      </div>
    </div>

    <button class="btn btn-primary"><?php echo app('translator')->get('main.submit'); ?></button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/MADO/resources/views/passwords/create.blade.php ENDPATH**/ ?>