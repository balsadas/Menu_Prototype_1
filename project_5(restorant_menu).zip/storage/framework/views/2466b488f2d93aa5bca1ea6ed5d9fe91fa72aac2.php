

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.food_index'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.block-header.index', ['data' => ['title' => trans('main.foods'), 'route' => route('foods.create'), 'route_order' => route('foods.order') ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <form action="" method="GET">
    <div class="form-row">
      <div class="col-md-8 mb-3 pt-2">
        <label class="form-label" for="search"><span><?php echo app('translator')->get('main.search'); ?></span></label>
        <input type="text" class="form-control" name="q" value="<?php echo e(request('q')); ?>" placeholder="Name">
      </div>
      <div class="col-md-3 mb-3 pt-2">
        <label class="form-label" for="category"><span><?php echo app('translator')->get('main.category'); ?></span></label>
        <select class="select" id="categories" name="categories[]" multiple="multiple">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->id); ?>" <?php if(in_array($category->id, request('categories', []))): ?> selected
                  <?php endif; ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      </div>
      <div class="col-md-1 mb-3 pt-5">
          <button class="btn btn-primary" type="submit"><i data-icon="search"></i></button>
      </div>
    </div>
  </form>
  <?php echo $__env->make('include.tables.foods', ['data' => ['foods' => $foods]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('.select').select2({
                width: '100%',
                minimumResultsForSearch: -1
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pikir\gurnamalylar\hojamyrat\resources\views/foods/index.blade.php ENDPATH**/ ?>