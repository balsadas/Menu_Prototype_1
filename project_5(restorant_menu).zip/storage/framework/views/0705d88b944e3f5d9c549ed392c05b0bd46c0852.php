<div class="hiddenLang justify-center items-center popup-image">
    <div class="flex flex-col  w-auto h-auto bg-[#fff] px-6 py-6 z-50 rounded-[4px]">
        
        <div  class="w-full text-right -mt-3 -mr-4 ">
            <span onclick="document.querySelector('.hiddenLang').style.display = 'none';" 
            class="text-[20px] slg:text-[22px] text-[#800080]">&times;</span>
        </div>
        <p class="text-[#800080] text-center text-[20px] font-[400px] -tracking-[0.02em] mb-[8px]"><?php echo e(trans('main.choose_lang')); ?></p>
        <div class="flex flex-col gap-[8px] text-[20px] font-[400px] -tracking-[0.02em]">
            <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="border: 1px solid rgba(255, 255, 255, 0.4);" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>" 
                class="TLWstyle bg-[#800080] hover:bg-[#4e134e] text-white text-[16px] ssm:text-[18px]">
                    <?php echo e($properties["native"]); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>  

    </div>
</div><?php /**PATH C:\xampp\htdocs\Pikir\gurnamalylar\hezzet\resources\views/components/lang.blade.php ENDPATH**/ ?>