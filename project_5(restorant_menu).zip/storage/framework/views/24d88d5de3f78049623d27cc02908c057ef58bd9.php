<!DOCTYPE html>
<html lang="en" class="js">

<head>
  <meta charset="utf-8">
  <meta name="author" content="Pikir">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
  <meta name="description" content="Menu dashboard for Restaurant hezzet">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="shortcut icon" href="<?php echo e(asset('icon/favicon.ico')); ?>" type="image/x-icon">
  <title><?php echo app('translator')->get('main.sign_in'); ?> | Menu Dashboard &mdash; Pikir</title>
  <link rel="stylesheet" href="<?php echo e(asset('cssPanel/app.css')); ?>">
  <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="nk-body npc-crypto ui-clean pg-auth">
<div class="nk-app-root">
  <div class="nk-split nk-split-page nk-split-md">
    <div class="nk-split-content nk-block-area nk-block-area-column nk-auth-container">
      <div class="absolute-top-right d-lg-none p-3 p-sm-5">
        <a href="#" class="toggle btn-white btn btn-icon btn-light" data-target="athPromo"><em class="icon ni ni-info"></em></a>
      </div>
      <div class="nk-block nk-block-middle nk-auth-body">
        <div class="brand-logo pb-5">
          <a href="<?php echo e(route('index')); ?>" class="logo-link">
            <img class="logo-light logo-img" src="<?php echo e(asset('images/logo-light.svg')); ?>" srcset="<?php echo e(asset('images/logo-light-2x.svg 2x')); ?>" alt="logo">
            <img class="logo-dark logo-img" src="<?php echo e(asset('images/logo-dark.svg')); ?>" srcset="<?php echo e(asset('images/logo-dark-2x.svg 2x')); ?>" alt="logo-dark">
          </a>
        </div>
        <div class="nk-block-head">
          <div class="nk-block-head-content">
            <h5 class="nk-block-title"><?php echo app('translator')->get('main.sign_in'); ?></h5>
            <div class="nk-block-des">
              <p><?php echo app('translator')->get('main.access_dashboard'); ?></p>
            </div>
          </div>
        </div>

        <form action="<?php echo e(route('login')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="form-label-group">
              <label class="form-label" for="username"><?php echo app('translator')->get('main.username'); ?></label>
            </div>
            <input type="text" class="form-control form-control-lg" id="username" placeholder="<?php echo app('translator')->get('main.enter_username'); ?>" name="username"
                   <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?> value="<?php echo e(old('username')); ?>" required autofocus>
            <?php if($errors->has('username')): ?>
              <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('username')); ?></strong></span>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <label class="form-label" for="password"><?php echo app('translator')->get('main.password'); ?></label>
            </div>
            <div class="form-control-wrap">
              <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch" data-target="password">
                <em class="passcode-icon icon-show icon ni ni-eye"></em>
                <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
              </a>
              <input type="password" class="form-control form-control-lg <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" id="password" name="password"
                     placeholder="<?php echo app('translator')->get('main.enter_password'); ?>">
              <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('password')); ?></strong></span>
              <?php endif; ?>
            </div>
          </div>
          <div class="custom-control custom-checkbox mb-4">
            <input type="checkbox" class="custom-control-input" name="remember" id="remember" value="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label class="custom-control-label" for="remember"><?php echo app('translator')->get('main.remember_me'); ?></label>
          </div>
          <div class="form-group">
            <button class="btn btn-lg btn-primary btn-block"><?php echo app('translator')->get('main.sign_in'); ?></button>
          </div>
        </form>
      </div>
      <div class="nk-block nk-auth-footer">
        <div class="nk-block-between">
          <ul class="nav nav-sm">
            <li class="nav-item dropup">
              <a class="dropdown-toggle dropdown-indicator has-indicator nav-link" data-toggle="dropdown" data-offset="0,10">
                <small><?php echo e(LaravelLocalization::getCurrentLocaleName()); ?></small>
              </a>
              <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right">
                <ul class="language-list">
                  <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($localeCode == app()->getLocale()): ?>
                      <li>
                        <a hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>" class="language-item">
                          <span class="language-name"><?php echo e($properties['native']); ?></span>
                        </a>
                      </li>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        <div class="mt-3">
          <p>&copy; <?php echo e(date('Y')); ?> <a href="http://pikir.biz">Pikir</a>. <?php echo app('translator')->get('main.all_rights_reserved'); ?>.</p>
        </div>
      </div>
    </div>

    <div class="nk-split-content nk-split-stretch bg-lighter d-flex toggle-break-lg toggle-slide toggle-slide-right" data-content="athPromo" data-toggle-screen="lg"
         data-toggle-overlay="true">
      <div class="slider-wrap w-100 w-max-550px p-3 p-sm-5 m-auto">
        <div class="slider-init" data-slick='{"dots":false, "arrows":false}'>
          <div class="slider-item">
            <div class="nk-feature nk-feature-center">
              <div class="nk-feature-img">
                
                <img class="round" src="<?php echo e(asset('images/dish.jpg')); ?>" srcset="<?php echo e(asset('images/dish.jpg')); ?>" alt="img">
              </div>
            </div>
          </div>
        </div>
        <div class="slider-dots"></div>
        <div class="slider-arrows"></div>
      </div>
    </div>
  </div>
</div>

<script src="<?php echo e(asset('js/bundle.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\user\Desktop\Work\project_5(restorant_menu)\resources\views/auth/login.blade.php ENDPATH**/ ?>