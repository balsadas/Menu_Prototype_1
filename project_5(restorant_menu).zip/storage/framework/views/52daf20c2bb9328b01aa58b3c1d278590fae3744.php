<?php if($data['items']->total() > $data['limit']): ?>
  <?php echo e($data['items']->onEachSide(1)->links()); ?>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\Pikir\gurnamalylar\hezzet\resources\views/include/paginate.blade.php ENDPATH**/ ?>