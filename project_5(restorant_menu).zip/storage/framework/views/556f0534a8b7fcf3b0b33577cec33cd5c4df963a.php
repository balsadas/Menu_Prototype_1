<div style="background: #1B2A50;" class="absolute top-0 flex flex-row justify-around w-full px-1 text-[12px] ssm:text-[13px] smd:text-[14px] slg:text-[16px] text-[#FFFFFF] z-50">
    <span>
        <a href="tel:212177">212177</a>
    </span>
    <span>
        <a href="tel:212199">212199</a>
    </span>
    <span>
        <a href="tel:721200">721200</a>
    </span>
</div><?php /**PATH /var/www/MADO/resources/views/components/number.blade.php ENDPATH**/ ?>