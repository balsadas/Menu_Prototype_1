<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.category_index'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.block-header.index', ['data' => ['title' => trans('main.categories'), 'route' => route('categories.create'), 'route_order' => route('categories.order') ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('include.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if(count($categories)): ?>
    <div class="nk-block">
      <div class="card card-bordered mb-5">
        <table class="table">
          <thead>
          <tr class="tb-tnx-head">
            <th></th>
            <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th><?php echo e($properties['native']); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <th><?php echo app('translator')->get('main.leaf'); ?></th>
            <th><?php echo app('translator')->get('main.foods'); ?></th>
            <th>&nbsp;</th>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="tb-tnx-item">
              <td><?php if($category->is_drink): ?> <em class="icon ni ni-coffee"></em> <?php endif; ?></td>
              <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($category->getTranslation('name', $locale)); ?></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              <td><?php if($category->is_leaf): ?> <em class="icon ni ni-check"></em> <?php else: ?> ― <?php endif; ?></td>
              <td><?php echo e($category->foodsCount()); ?></td>
              <td class="tb-col-action">
                <span class="mr-1"><a href="<?php echo e(route('categories.show', $category->id)); ?>" class="link-cross link-eye mr-sm-n1"><em class="icon ni ni-eye"></em></a></span>
                <span class="mr-1"><a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="link-cross link-edit mr-sm-n1"><em class="icon ni ni-edit-alt"></em></a></span>
                <span>
                  <a href="#" onclick="if (confirm('<?php echo e(trans("main.want_to_remove")); ?>')) { document.getElementById('destroy-<?php echo e($category->id); ?>').submit(); }"
                         class="link-cross mr-sm-n1"><em class="icon ni ni-trash"></em>
                      </a></span>
                <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="post" id="destroy-<?php echo e($category->id); ?>">
                  <?php echo method_field('delete'); ?>
                  <?php echo csrf_field(); ?>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <?php echo $__env->make('include.paginate', ['data' => ['items' => $categories, 'limit' => 10]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  <?php else: ?>
    <p><?php echo app('translator')->get('main.no_category'); ?></p>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/MADO/resources/views/categories/index.blade.php ENDPATH**/ ?>