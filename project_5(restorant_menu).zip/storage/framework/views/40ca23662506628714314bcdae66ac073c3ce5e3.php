  <form action="" method="GET">
    <div class="form-row">
      <div class="col-md-11 mb-3 pt-2">
        <label class="form-label" for="search"><span><?php echo app('translator')->get('main.search'); ?></span></label>
        <input type="text" class="form-control" name="q" value="<?php echo e(request('q')); ?>" placeholder="Name">
      </div>
      <div class="col-md-1 mb-3 pt-5">
          <button class="btn btn-primary" type="submit"><i data-icon="search"></i></button>
      </div>
    </div>
  </form><?php /**PATH C:\Users\user\Desktop\Work\project_5(restorant_menu)\resources\views/include/search.blade.php ENDPATH**/ ?>