export default {
  Powered: "Powered by Pikir.",
  appLocales: ["en", "tm", "ru", "tr"],
  storePhones: [ "+993(12) 72-99-45", ],
  phone: "+99364552554",
  currency: "TMT",

  _welcome: "/",
  _catalog: "/catalog",
  _items: "/items",
  inst: "@soltan",
  tik: "@soltan",
  address: "Aşgabat ş.,Köşi Taslama, Gülzemin söwda merkezi 3-nji gaty ",
  inst:'@kebapcytm_gulzemin',


};
