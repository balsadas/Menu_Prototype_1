export default {
  en: {
    appName: "MENU",
    tm: " Türkmen",
    ru: "Русский",
    en: "English",
    tr: "Türkçe",
    ChooseLanguage: "Choose language",
    DarkMode: "Dark Mode",
    LightMode: "Light Mode",
    Categories: "Categories",
    Call: "Call",
  },

  ru: {
    appName: "МЕНЮ",
    tm: " Türkmen",
    ru: "Русский",
    en: "English",
    tr: "Türkçe",
    ChooseLanguage: "Выберите язык",
    DarkMode: "Темный режим",
    LightMode: "Легкий режим",
    Categories: "Категории",
    Call: "Вызов",
  },

  tr: {
    appName: "MENÜ",
    tm: " Türkmen",
    ru: "Русский",
    en: "English",
    tr: "Türkçe",
    ChooseLanguage: "Dil seçiniz",
    DarkMode: "Karanlık Mod",
    LightMode: "Işık Modu",
    Categories: "Kategoriler",
    Call: "Arama",
  },

  tm: {
    appName: "MENU",
    tm: " Türkmen",
    ru: "Русский",
    en: "English",
    tr: "Türkçe",
    ChooseLanguage: "Dil saýlaň",
    DarkMode: "Gije rejim",
    LightMode: "Gündiz rejim",
    Categories: "Kategoriýalar",
    Call: "Jaňlaşmak",

  },
};
