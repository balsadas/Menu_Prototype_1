import { Constants } from "../../common";
import { useState } from "react";
import CloseIcon from "../../assets/icons/ItemClose";

import "./css.css";

export default function Card({ image, discount, sizes, name, lang }) {
  const [isOpen, setOpen] = useState(false);

  const size = sizes[0];
  console.log(name, lang)
  return (
    <div className="item-card">
      <img onClick={() => setOpen(true)} src={image} alt="SS" />
      <div onClick={() => setOpen(true)}>
        <div className="container">
          <div className="food-description">
            <div className="inner-frame">
              <div className="sale">
                {
                  size.discount_price && (
                    <>
                    <div className="percentage">
                      <span className="text b-medium">
                        <span>{discount}%</span>
                      </span>
                    </div>
                    <div className="saleprice">
                      <span className="text01 b-medium">
                        <span>{size.price}{Constants.currency}</span>
                      </span>
                      <img
                        src="/images/vector1.svg"
                        alt="Vector1I1997"
                        className="vector1"
                      />
                    </div>
                    </>
                  )
                }
              </div>
              <div className="price">
                <span className="text h-semibold">
                  <span>{size.discount_price ? size.discount_price : size.price}</span>
                </span>
                <div className="frame2286">
                  <span
                    className="text b-medium"
                  >
                    <span>{Constants.currency}</span>
                  </span>
                </div>
              </div>
            </div>
          
            <span className="text0 b-regular">
              <span>
              {name[lang]}
                <span
                  dangerouslySetInnerHTML={{
                    __html: " ",
                  }}
                />
              </span>
            </span>
          </div>
        </div>
      </div>
      {/* End New */}

      {isOpen && (
        <>
          <div className="placeholder" onClick={() => setOpen(false)} />
          <div className="item-viewer">
            <div className="images" >
              <img src={image} alt="SS" />
            </div>
            <span onClick={() => setOpen(false)} className="closer">
              <CloseIcon />
            </span>
            <div className="item-info">
              <div className="p-container">
                <div className="fooddescription">
                  <span
                    className="pop-up-text p-h-semibold">
                    <span>
                    {name[lang]}
                      <span
                        dangerouslySetInnerHTML={{
                          __html: " ",
                        }}
                      />
                    </span>
                  </span>


                  {
                    size.discount_price && (
                      <div className="p-sale" style={{marginTop : 10}}>
                        <div className="percentage">
                          <span className="text02 p-b-medium">
                            <span>{discount}%</span>
                          </span>
                        </div>
                        <div className="saleprice">
                          <span
                            className="text04 p-b-medium"
                          >
                            <span style={{whiteSpace: "nowrap", textDecoration: 'line-through', textDecorationColor: "red"}}>
                              {size.price} {Constants.currency}
                            </span>
                          </span>
                        </div>
                      </div>
                    )
                  }


                </div>
              </div>
              <span>{size.discount_price ? size.discount_price : size.price}{Constants.currency}</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
