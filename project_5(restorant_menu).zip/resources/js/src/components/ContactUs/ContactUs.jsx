import React from "react";
import Marquee from "../../pages/Items/Marquee";
import Constants from "../../common/Constants";
import { useAppContext } from "../../Context";

import "./css.css";

function ContactUs() {
    const { state } = useAppContext();
    return (
        <div >
            <Marquee title={"Biz bilen Habarlasyn"} />
            <div className="contact">
                <div>
                    <div style={{ marginTop: "2.5rem" }}>
                        <h2
                            style={{
                                color:
                                    state.mode == "dark" ? "#fff" : "#515151",
                                fontSize: "18px",
                                textTransform: "uppercase",
                                display: "flex",
                                justifyContent: "center",
                                userSelect: "none",
                            }}
                        >
                            Instagram
                        </h2>
                        <h2
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                userSelect: "none",
                            }}
                        >
                            <a
                                style={{
                                    marginTop: "1rem",
                                    color: "inherit",
                                    textDecoration: "none",
                                    fontSize: "18px",
                                }}
                                href='https://www.instagram.com/kebapcytm/'
                            >
                                {Constants.inst}
                            </a>
                        </h2>
                    </div>
                    <div style={{ marginTop: "2.5rem" }}>
                        <h2
                            style={{
                                color:
                                    state.mode == "dark" ? "#fff" : "#515151",
                                fontSize: "18px",
                                textTransform: "uppercase",
                                display: "flex",
                                justifyContent: "center",
                                userSelect: "none",
                            }}
                        >
                            Telefon
                        </h2>
                        <div
                            style={{
                                display: "grid",
                                gridRow: "3",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            {Constants.storePhones.map((phone, i) => (
                                <a
                                    style={{
                                        marginTop: "1rem",
                                        color: "inherit",
                                        textDecoration: "none",
                                        fontSize: "18px",
                                    }}
                                    href={"tel:" + phone}
                                    key={i}
                                >
                                    {phone}
                                </a>
                            ))}
                        </div>
                    </div>
                    <div style={{ marginTop: "2.5rem" }}>
                        <h2
                            style={{
                                color:
                                    state.mode == "dark" ? "#fff" : "#515151",
                                fontSize: "18px",
                                textTransform: "uppercase",
                                display: "flex",
                                justifyContent: "center",
                                userSelect: "none",
                            }}
                        >
                            Salgy
                        </h2>
                        <h2
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                userSelect: "none",
                                fontSize:'18px',
                                textAlign:'center'
                            }}
                        >
                            {Constants.address}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ContactUs;
