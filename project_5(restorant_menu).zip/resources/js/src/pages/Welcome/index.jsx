import Content from "./Content";
import "./css.css";

function Welcome() {
  return (
    <div className="w-wrapper">
      <Content />
    </div>
  );
}

export default Welcome;
