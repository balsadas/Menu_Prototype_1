import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "./Context";
import AppRoutes from "./Routes";
import "react-toastify/dist/ReactToastify.css";
import "./assets/css/index.css";

// export default function Main(){
//     return (
//         <h1>Hello React!</h1>
//     );
// }


if (document.getElementById("com.ayegenmyradow")) {
    ReactDOM.render(
       
        <Provider>
        
            <AppRoutes />
        </Provider>,
        document.getElementById("com.ayegenmyradow")
    );
}
